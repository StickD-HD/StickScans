"""
Copie partagée des pages de séries entre plusieurs instances StickScans d'un même serveur.

Principe : l'instance « principale » enregistre chaque page qu'elle récupère sur le site ; une instance
« secondaire » réutilise cette copie (si elle est assez récente) au lieu de redemander la page au site.
Le partage est à SENS UNIQUE : l'instance secondaire ne peut que lire. Les séries qu'elle suit seule sont
récupérées normalement.

Réglages (variables d'environnement) :
- SCRAPE_CACHE_MODE            : "off" (défaut), "write" (principale), "read" (secondaire) ou "both" (les deux instances lisent ET écrivent).
- SCRAPE_CACHE_DIR             : dossier de la copie (le même pour les deux instances).
- SCRAPE_CACHE_MAX_AGE_MINUTES : âge maximal d'une copie réutilisable (défaut : 90).
"""
import gzip
import hashlib
import logging
import os
import time
from pathlib import Path

logger = logging.getLogger("manhwa-tracker.cache")

# Activation : définir SCRAPE_CACHE_DIR (le partage passe alors en mode "both" sauf SCRAPE_CACHE_MODE).
CACHE_DIR = Path(os.environ["SCRAPE_CACHE_DIR"]) if os.environ.get("SCRAPE_CACHE_DIR") else None
MODE = os.environ.get("SCRAPE_CACHE_MODE", "").strip().lower() or ("both" if CACHE_DIR else "off")
if MODE not in ("off", "read", "write", "both"):
    MODE = "off"
MAX_AGE_SECONDS = max(1, int(os.environ.get("SCRAPE_CACHE_MAX_AGE_MINUTES", "90") or 90)) * 60
ORPHAN_DAYS = 3  # une copie plus ancienne n'est plus utile (série supprimée, par exemple)


def is_active() -> bool:
    return MODE in ("read", "write", "both") and CACHE_DIR is not None


def _path_for(url: str) -> Path:
    name = hashlib.sha256(url.strip().encode()).hexdigest()[:32] + ".html.gz"
    return CACHE_DIR / name


def read(url: str) -> tuple[str, float] | None:
    """Renvoie (html, âge en secondes) si une copie assez récente existe, sinon None."""
    if MODE not in ("read", "both") or CACHE_DIR is None:
        return None
    try:
        path = _path_for(url)
        age = time.time() - path.stat().st_mtime
        if age > MAX_AGE_SECONDS or age < -60:  # trop vieille (ou horloge incohérente)
            return None
        with gzip.open(path, "rt", encoding="utf-8") as f:
            return f.read(), max(0.0, age)
    except (OSError, EOFError, UnicodeError):
        return None  # absente, illisible ou en cours d'écriture : on ira sur le site


def write(url: str, html: str) -> None:
    if MODE not in ("write", "both") or CACHE_DIR is None:
        return
    try:
        CACHE_DIR.mkdir(parents=True, exist_ok=True)
        path = _path_for(url)
        tmp = path.with_suffix(".tmp")
        with gzip.open(tmp, "wt", encoding="utf-8", compresslevel=6) as f:
            f.write(html)
        os.replace(tmp, path)  # remplacement atomique : l'autre instance ne lit jamais un fichier à moitié écrit
    except OSError as e:
        logger.warning("Copie de page non enregistrée : %s", e)


def purge_old() -> None:
    if MODE not in ("write", "both") or CACHE_DIR is None or not CACHE_DIR.exists():
        return
    limit = time.time() - ORPHAN_DAYS * 86400
    for path in CACHE_DIR.glob("*.html.gz"):
        try:
            if path.stat().st_mtime < limit:
                path.unlink()
        except OSError:
            pass


def stats() -> dict:
    """État du cache des pages : actif ou non, dossier, nombre de fichiers et taille."""
    files = size = 0
    if CACHE_DIR is not None and CACHE_DIR.exists():
        for path in CACHE_DIR.glob("*.html.gz"):
            try:
                size += path.stat().st_size
                files += 1
            except OSError:
                pass
    return {
        "active": is_active(),
        "mode": MODE,
        "dir": str(CACHE_DIR) if CACHE_DIR is not None else None,
        "files": files,
        "bytes": size,
        "max_age_minutes": MAX_AGE_SECONDS // 60,
    }


def clear() -> tuple[int, int]:
    """Supprime toutes les pages en cache (même celles que l'autre instance pourrait réutiliser : elles seront
    simplement redemandées au site). Renvoie (fichiers supprimés, octets libérés)."""
    files = freed = 0
    if CACHE_DIR is not None and CACHE_DIR.exists():
        for path in list(CACHE_DIR.glob("*.html.gz")) + list(CACHE_DIR.glob("*.tmp")):
            try:
                size = path.stat().st_size
                path.unlink()
                files += 1
                freed += size
            except OSError:
                pass
    return files, freed
